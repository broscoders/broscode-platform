import mongoose from "mongoose";

interface GroqMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string;
  tool_call_id?: string;
  tool_calls?: ToolCall[];
}

interface ToolCall {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
}

let cachedModel: string | null = null;

const MODEL_PREFERENCE = [
  "openai/gpt-oss-120b",
  "openai/gpt-oss-20b",
  "qwen/qwen3.6-27b",
  "moonshotai/kimi-k2-instruct-0905",
  "llama-4-maverick-17b-128e-instruct",
  "llama-4-scout-17b-16e-instruct",
];

const NON_CHAT_MODELS = new Set([
  "canopylabs/orpheus-v1-english",
  "canopylabs/orpheus-arabic-saudi",
  "whisper-large-v3",
  "whisper-large-v3-turbo",
  "distil-whisper-large-v3-en",
  "playai-tts",
]);

function isChatModel(id: string): boolean {
  if (NON_CHAT_MODELS.has(id)) return false;
  const lower = id.toLowerCase();
  return !(
    lower.includes("whisper") ||
    lower.includes("tts") ||
    lower.includes("guard") ||
    lower.includes("orpheus")
  );
}

async function resolveModel(apiKey: string): Promise<string> {
  if (cachedModel) return cachedModel;

  try {
    const resp = await fetch("https://api.groq.com/openai/v1/models", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    if (resp.ok) {
      const data = (await resp.json()) as { data?: Array<{ id: string }> };
      const available = new Set((data.data ?? []).map((m) => m.id));

      for (const preferred of MODEL_PREFERENCE) {
        if (available.has(preferred)) {
          cachedModel = preferred;
          return preferred;
        }
      }

      const firstChatModel = (data.data ?? []).find((m) => isChatModel(m.id))?.id;
      if (firstChatModel) {
        cachedModel = firstChatModel;
        return firstChatModel;
      }
    }
  } catch (err) {
    console.error("[groq] Failed to fetch model list:", err);
  }

  cachedModel = MODEL_PREFERENCE[0];
  return cachedModel;
}

// ---------------------------------------------------------------------------
// TOOL DEFINITIONS
// ---------------------------------------------------------------------------
const TOOLS = [
  {
    type: "function",
    function: {
      name: "count_leads",
      description: "Get the total count of leads, optionally filtered by status.",
      parameters: {
        type: "object",
        properties: {
          status: {
            type: "string",
            description: "Optional filter, e.g. 'new', 'contacted', 'converted', 'lost'. Omit for total count.",
          },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "count_customers",
      description: "Get the total count of customers.",
      parameters: { type: "object", properties: {} },
    },
  },
  {
    type: "function",
    function: {
      name: "get_deals_summary",
      description: "Get deal counts and total value, optionally filtered by status.",
      parameters: {
        type: "object",
        properties: {
          status: {
            type: "string",
            description: "Optional filter, e.g. 'open', 'won', 'lost'. Omit for all deals.",
          },
        },
      },
    },
  },
  {
    type: "function",
    function: {
      name: "count_projects",
      description: "Get the total count of projects, optionally filtered by status.",
      parameters: {
        type: "object",
        properties: {
          status: {
            type: "string",
            description: "Optional filter, e.g. 'active', 'completed'. Omit for total count.",
          },
        },
      },
    },
  },
];

// ---------------------------------------------------------------------------
// TOOL EXECUTORS — real Mongoose queries.
// ⚠️ Replace `Lead`, `Customer`, `Deal`, `Project` with your real model imports,
// and adjust field names (`status`, `value`) to match your schemas.
// ---------------------------------------------------------------------------
import Lead from "../models/Lead";
import Customer from "../models/Customer";
import Deal from "../models/Deal";
import Project from "../models/Project";

async function executeTool(name: string, args: Record<string, any>): Promise<string> {
  try {
    switch (name) {
      case "count_leads": {
        const filter = args.status ? { status: args.status } : {};
        const count = await Lead.countDocuments(filter);
        return JSON.stringify({ count, filter: args.status ?? "all" });
      }

      case "count_customers": {
        const count = await Customer.countDocuments({});
        return JSON.stringify({ count });
      }

      case "get_deals_summary": {
        const filter = args.status ? { status: args.status } : {};
        const deals = await Deal.find(filter).select("value").lean();
        const totalValue = deals.reduce((sum, d: any) => sum + (d.value ?? 0), 0);
        return JSON.stringify({
          count: deals.length,
          totalValue,
          filter: args.status ?? "all",
        });
      }

      case "count_projects": {
        const filter = args.status ? { status: args.status } : {};
        const count = await Project.countDocuments(filter);
        return JSON.stringify({ count, filter: args.status ?? "all" });
      }

      default:
        return JSON.stringify({ error: `Unknown tool: ${name}` });
    }
  } catch (err) {
    console.error(`[tool:${name}] execution failed:`, err);
    return JSON.stringify({ error: "Failed to fetch this data. Please try again." });
  }
}

// ---------------------------------------------------------------------------

const SYSTEM_INSTRUCTION = `You are a business assistant that answers questions using ONLY the tools provided to you (leads, customers, deals, projects data).
Rules:
- NEVER guess or make up numbers. Always call the relevant tool(s) to get real data before answering.
- For broad/general questions (e.g. "how is business going", "business kaisa ja raha hai", "give me an overview"), call ALL relevant tools (count_leads, count_customers, get_deals_summary, count_projects) and combine the results into a short overview. Do NOT refuse or say data is unavailable — the tools give you everything needed for a general summary.
- Only say data is unavailable if the question asks for something no tool can provide (e.g. a specific person's phone number, or historical data older than what the tools return).
- For casual small talk not related to the business (e.g. "how are you", "kasy ho"), reply briefly and warmly in one line, then gently steer back — e.g. mention you're here to help with their leads/deals/customers data.
- ALWAYS reply in the same language and script the user used in their latest message. Roman Urdu in, Roman Urdu out. English in, English out. Urdu script in, Urdu script out.
- Keep answers short and direct — lead with the number/fact, then a brief one-line context if useful.`;

const MAX_HISTORY_MESSAGES = 12;

function trimHistory(messages: GroqMessage[]): GroqMessage[] {
  const nonSystem = messages.filter((m) => m.role !== "system");
  if (nonSystem.length <= MAX_HISTORY_MESSAGES) return nonSystem;
  return nonSystem.slice(nonSystem.length - MAX_HISTORY_MESSAGES);
}

async function callGroqWithRetry(
  apiKey: string,
  model: string,
  messages: GroqMessage[],
  useTools: boolean,
  attempt = 1
): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20000);

  try {
    const resp = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.2,
        max_tokens: 800,
        ...(useTools ? { tools: TOOLS, tool_choice: "auto" } : {}),
      }),
      signal: controller.signal,
    });

    if ((resp.status === 429 || resp.status >= 500) && attempt < 3) {
      await new Promise((r) => setTimeout(r, attempt * 1000));
      return callGroqWithRetry(apiKey, model, messages, useTools, attempt + 1);
    }

    return resp;
  } catch (err) {
    if (attempt < 3) {
      await new Promise((r) => setTimeout(r, attempt * 1000));
      return callGroqWithRetry(apiKey, model, messages, useTools, attempt + 1);
    }
    throw err;
  } finally {
    clearTimeout(timeout);
  }
}

function assertConfigured(): string {
  const apiKey = process.env.GROQ_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GROQ_API_KEY is not set. Add it to server/.env - get a free key at console.groq.com."
    );
  }
  return apiKey;
}

export async function askGroq(messages: GroqMessage[]): Promise<string> {
  const apiKey = assertConfigured();

  const userMessages = messages.filter((m) => m.role !== "system");
  const lastUserMessage = [...userMessages].reverse().find((m) => m.role === "user");

  if (!lastUserMessage || !lastUserMessage.content.trim()) {
    return "Please type a question first.";
  }

  const model = await resolveModel(apiKey);
  const trimmed = trimHistory(messages);
  let conversation: GroqMessage[] = [
    { role: "system", content: SYSTEM_INSTRUCTION },
    ...trimmed,
  ];

  try {
    let resp = await callGroqWithRetry(apiKey, model, conversation, true);

    if (!resp.ok) {
      const text = await resp.text();
      console.error(`[groq] Request failed (${resp.status}):`, text);
      if (resp.status === 404) cachedModel = null;
      if (resp.status === 429) return "System is a bit busy right now, please try again in a moment.";
      if (resp.status >= 500) return "AI service is temporarily unavailable. Please try again shortly.";
      return "Sorry, I couldn't process that request. Please try rephrasing your question.";
    }

    let data = await resp.json();
    let message = data.choices?.[0]?.message;

    let rounds = 0;
    while (message?.tool_calls?.length && rounds < 3) {
      conversation.push({
        role: "assistant",
        content: message.content ?? "",
        tool_calls: message.tool_calls,
      });

      for (const toolCall of message.tool_calls as ToolCall[]) {
        const args = JSON.parse(toolCall.function.arguments || "{}");
        const result = await executeTool(toolCall.function.name, args);
        conversation.push({
          role: "tool",
          tool_call_id: toolCall.id,
          content: result,
        });
      }

      resp = await callGroqWithRetry(apiKey, model, conversation, true);
      if (!resp.ok) {
        const text = await resp.text();
        console.error(`[groq] Tool follow-up failed (${resp.status}):`, text);
        return "Sorry, I couldn't complete that request. Please try again.";
      }
      data = await resp.json();
      message = data.choices?.[0]?.message;
      rounds++;
    }

    return message?.content?.trim() ?? "I could not generate a response.";
  } catch (err) {
    console.error("[groq] Unexpected error:", err);
    return "Something went wrong while processing your request. Please try again.";
  }
}